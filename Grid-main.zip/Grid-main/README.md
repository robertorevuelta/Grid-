# botonBasico
Plantilla para descargar y empezar con algo de Javascript
